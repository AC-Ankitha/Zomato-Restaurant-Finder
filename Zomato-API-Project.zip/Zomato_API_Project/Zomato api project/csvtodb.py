import pandas as pd
from sqlalchemy import create_engine

# Loading CSV file into a pandas DataFrame 
csv_file = 'zomato.csv'  
df = pd.read_csv(csv_file, encoding='latin1') 

# Creating  SQLite database 
engine = create_engine('sqlite:///Zomato_database.db')  # SQLite database file
connection = engine.connect()

# Writing the DataFrame to the database
df.to_sql('zomato', con=connection, if_exists='replace', index=False)

# Closing the connection
connection.close()

print(f"CSV file '{csv_file}' has been successfully converted to SQLite DB.")
